﻿
namespace Pensja
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roz = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ZP = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.month = new System.Windows.Forms.ComboBox();
            this.year = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.p = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // roz
            // 
            this.roz.Location = new System.Drawing.Point(178, 231);
            this.roz.Name = "roz";
            this.roz.Size = new System.Drawing.Size(101, 23);
            this.roz.TabIndex = 0;
            this.roz.Text = "Розрахувати";
            this.roz.UseVisualStyleBackColor = true;
            this.roz.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Зарплата у грн.";
         
            // 
            // ZP
            // 
            this.ZP.Location = new System.Drawing.Point(26, 69);
            this.ZP.Name = "ZP";
            this.ZP.Size = new System.Drawing.Size(100, 23);
            this.ZP.TabIndex = 3;
         
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(253, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Місяць та рік офіційного працевлаштування";
          
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(126, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Заповніть нижні поля";
            // 
            // month
            // 
            this.month.FormattingEnabled = true;
            this.month.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.month.Location = new System.Drawing.Point(26, 142);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(66, 23);
            this.month.TabIndex = 6;
           
            // 
            // year
            // 
            this.year.Location = new System.Drawing.Point(98, 142);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(67, 23);
            this.year.TabIndex = 7;
         
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Вік";
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(26, 207);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(54, 23);
            this.age.TabIndex = 9;
          
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Ваша пенсія = ";
            // 
            // p
            // 
            this.p.AutoSize = true;
            this.p.Location = new System.Drawing.Point(121, 289);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(10, 15);
            this.p.TabIndex = 11;
            this.p.Text = " ";
          
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 346);
            this.Controls.Add(this.p);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.age);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.year);
            this.Controls.Add(this.month);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ZP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.roz);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button roz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ZP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox month;
        private System.Windows.Forms.TextBox year;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label p;
    }
}

