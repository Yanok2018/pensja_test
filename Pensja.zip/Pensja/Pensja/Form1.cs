﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pensja
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double zp = 0;
            if (ZP.Text != string.Empty)
            {   
                double pensija = 0;//сама пенсія
                
                zp = Convert.ToDouble(ZP.Text);//зчитуєм зп
                if (month.Text != string.Empty)//якщо поле місяця не пусте
                {   
                    int mis = Convert.ToInt32(month.Text);//зчитуєм місяці відразу в тип int
                    DateTime datenow = DateTime.Today;//записуєм дату на даний момент
                    if (year.Text != string.Empty)//якщо поле року не пусте 
                    {
                        int rik = Convert.ToInt32(year.Text);//зчитуєм рік відразу в тип int
                        DateTime date = new DateTime(rik, mis, 01);//записуєм дату яку було введенно
                        int stazh = ((datenow.Year - date.Year) * 12) + datenow.Month - date.Month;//рахуєм стаж
                        if(age.Text != string.Empty)//якщо вік людини не пустий
                        {
                            double kc = (stazh * 0.0135) / (100 * 12);//рахуєм коефіціент страхового стажу 
                            if (Convert.ToInt32(age.Text) >= 60)//якщо від людини 60 і більше років то добавляєм 1% від зп за кожний місяць
                            {
                                //+%
                                int ages = Convert.ToInt32(age.Text);//отримуєм вік людини в тип int
                                int temp = ages - 60;//тимчасова зміна для визначення років
                                double temp2 = 0;
                                for (int i = 0; i < temp * 12; i++)//цикл for для визначення кількості місяців і кількості грн для добавки до пенсії
                                {
                                    temp2 = temp2 + (zp * 0.01);//добавляєм 1% від зп за кожний місяць
                                }
                                pensija = zp * (kc * 100)+(temp2);//формула для розрахунку пенсії з надбавку
                                p.Text = pensija.ToString() + " грн.";//вивід пенсії
                            }
                            else //якщо людині менше 60
                            {
                                pensija = zp * (kc*100);//формула для розрахунку пенсії
                                p.Text = pensija.ToString() + " грн.";//вивід пенсії
                            }
                        }
                    }
                }
            }
        }

      
    }
}
